{
    "orientation": "landscape", /* Could be "landscape" or "portrait" */
    "name": "TITLE",
    "display": "standalone"
}